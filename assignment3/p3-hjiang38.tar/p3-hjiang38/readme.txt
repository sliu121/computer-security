name:Hanliang Jiang     email:hjiang38@binghamton.edu
name:Siyu Liu   email: sliu121@binghamton.edu
code was not tested on bingsuns
run makefile first then use ./gen-pass first to generate ID and password.
Then use ./sslserv 7838 to run the server.
Then use ./sslcli 127.0.0.1 7838 to run the client
Then input ID and password in the server which you want to test.
For example,you want to test ID:qwe and password:asdf exist or not.You can input qwe asdf in client.
If you have any questions,we can demo during your office hour.